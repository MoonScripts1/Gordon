PLUGSKAY WEBSITE
================

Open index.html in a browser to preview the store.

This version is a mobile-first storefront based on the supplied video:
- dark PlugSkay-style layout
- 26 product cards
- prices/sale prices transcribed from the video where visible
- search
- working add-to-cart drawer
- email signup section
- responsive desktop layout

For a real shop, connect Checkout to a payment provider and replace the extracted
video imagery with your own product photos before publishing.
